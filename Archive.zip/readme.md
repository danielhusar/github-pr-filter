# Github Pr Filter

Add ability to filter files in pull requests

## Install

Install it from [chrome store](https://chrome.google.com/webstore/detail/github-pr-filter/fjmalelcdgindphooaabcgmmnmoclpee), or download this repo and load as unpacked extension.

## Example

![](demo.png)

## License

MIT © [Daniel Husar](https://github.com/danielhusar)
