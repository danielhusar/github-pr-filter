# Github Pr Filter

Add ability to filter files in pull requests

## Install

Install it from [chrome store](), or download this repo and load as unpacked extension.

## Example

![](demo.png)

## License

MIT © [Daniel Husar](https://github.com/danielhusar)
